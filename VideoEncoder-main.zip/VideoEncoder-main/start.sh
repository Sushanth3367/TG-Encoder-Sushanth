python3 -m SmartEncoder
