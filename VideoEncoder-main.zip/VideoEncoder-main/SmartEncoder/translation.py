# Translation

class Translation:
  # start text
  START_TEXT = "𝙃𝙞, 𝙄 𝙖𝙢 𝙖𝙣 [𝘼𝙣𝙞𝙢𝙚](https://te.legra.ph/file/1d077772d84efcca8e103.jpg) 𝙏𝙝𝙚𝙢𝙚𝙙 𝘽𝙤𝙩.\n𝙄 𝙖𝙢 𝙗𝙪𝙞𝙡𝙩 𝙩𝙤 𝙚𝙣𝙘𝙤𝙙𝙚 𝙖𝙣𝙞𝙢𝙚𝙨 𝙛𝙤𝙧 𝙬𝙚𝙚𝙗𝙨.\n𝙄 𝙨𝙥𝙚𝙘𝙞𝙖𝙡𝙞𝙯𝙚 𝙞𝙣 𝙢𝙖𝙣𝙖𝙜𝙞𝙣𝙜 𝙢𝙮 𝙤𝙬𝙣𝙚𝙧'𝙨 𝙘𝙝𝙖𝙣𝙣𝙚𝙡."
  HELP_TEXT = "𝙄 𝙖𝙢 𝙖 [𝙥𝙤𝙬𝙚𝙧𝙛𝙪𝙡](https://te.legra.ph/file/7d61110fe44778999a95b.jpg) 𝙫𝙞𝙙𝙚𝙤 𝙚𝙣𝙘𝙤𝙙𝙞𝙣𝙜 𝙗𝙤𝙩 𝙗𝙪𝙞𝙡𝙩 𝙞𝙣 𝙥𝙮𝙩𝙝𝙤𝙣.\n𝙃𝙤𝙨𝙩𝙚𝙙 𝙤𝙣 𝙖 𝙥𝙤𝙬𝙚𝙛𝙪𝙡 𝙨𝙚𝙧𝙫𝙚𝙧, 𝙞 𝙖𝙢 𝙖𝙗𝙡𝙚 𝙩𝙤 𝙚𝙣𝙘𝙤𝙙𝙚 𝙛𝙖𝙨𝙩𝙚𝙧.\n𝙄 𝙢𝙖𝙣𝙖𝙜𝙚 [𝘼𝙣𝙞𝙑𝙤𝙞𝙙](https://t.me/AniVoid)."
